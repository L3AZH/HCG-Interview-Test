package com.l3azh.hcginterviewservicesbooking.hcginterviewservicesbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HcgInterviewServicesBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
