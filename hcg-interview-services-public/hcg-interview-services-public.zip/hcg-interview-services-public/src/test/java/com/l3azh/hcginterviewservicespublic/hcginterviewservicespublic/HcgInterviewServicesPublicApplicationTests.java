package com.l3azh.hcginterviewservicespublic.hcginterviewservicespublic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HcgInterviewServicesPublicApplicationTests {

	@Test
	void contextLoads() {
	}

}
