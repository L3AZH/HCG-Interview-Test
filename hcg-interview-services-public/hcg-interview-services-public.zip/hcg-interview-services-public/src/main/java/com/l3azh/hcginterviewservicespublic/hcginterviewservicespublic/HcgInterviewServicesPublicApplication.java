package com.l3azh.hcginterviewservicespublic.hcginterviewservicespublic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HcgInterviewServicesPublicApplication {

	public static void main(String[] args) {
		SpringApplication.run(HcgInterviewServicesPublicApplication.class, args);
	}

}
